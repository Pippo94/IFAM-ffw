/*
 * Academic Student License -- for use by students to meet course
 * requirements and perform academic research at degree granting
 * institutions only.  Not for government, commercial, or other
 * organizational use.
 * File: ffw_exe_types.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 19-Mar-2020 12:57:10
 */

#ifndef FFW_EXE_TYPES_H
#define FFW_EXE_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for ffw_exe_types.h
 *
 * [EOF]
 */
