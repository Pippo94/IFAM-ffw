/*
 * Academic Student License -- for use by students to meet course
 * requirements and perform academic research at degree granting
 * institutions only.  Not for government, commercial, or other
 * organizational use.
 * File: ffw_exe_terminate.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 19-Mar-2020 12:57:10
 */

#ifndef FFW_EXE_TERMINATE_H
#define FFW_EXE_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ffw_exe_types.h"

/* Function Declarations */
extern void ffw_exe_terminate(void);

#endif

/*
 * File trailer for ffw_exe_terminate.h
 *
 * [EOF]
 */
