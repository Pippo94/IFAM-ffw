/*
 * Academic Student License -- for use by students to meet course
 * requirements and perform academic research at degree granting
 * institutions only.  Not for government, commercial, or other
 * organizational use.
 * File: path_file_Modell3dof_Testkreis.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 19-Mar-2020 12:57:10
 */

#ifndef PATH_FILE_MODELL3DOF_TESTKREIS_H
#define PATH_FILE_MODELL3DOF_TESTKREIS_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ffw_exe_types.h"

/* Function Declarations */
extern void path_file_Modell3dof_Testkreis(double type, double t, double t_max,
  const double p0pf[6], double path[2]);

#endif

/*
 * File trailer for path_file_Modell3dof_Testkreis.h
 *
 * [EOF]
 */
