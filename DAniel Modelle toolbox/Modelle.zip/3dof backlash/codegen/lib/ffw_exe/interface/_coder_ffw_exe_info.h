/* 
 * Academic Student License -- for use by students to meet course 
 * requirements and perform academic research at degree granting 
 * institutions only.  Not for government, commercial, or other 
 * organizational use. 
 * File: _coder_ffw_exe_info.h 
 *  
 * MATLAB Coder version            : 4.1 
 * C/C++ source code generated on  : 19-Mar-2020 12:57:10 
 */

#ifndef _CODER_FFW_EXE_INFO_H
#define _CODER_FFW_EXE_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_ffw_exe_info.h 
 *  
 * [EOF] 
 */
